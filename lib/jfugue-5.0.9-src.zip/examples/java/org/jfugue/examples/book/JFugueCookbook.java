package org.jfugue.examples.book;

import org.jfugue.player.Player;

public class JFugueCookbook {
    
    // The Quintessential Music Program
    public static final void main(String[] args) {
        Player player = new Player();
        player.play("C D E F G A B");
    }
    
    // 
}
